const registerSchema = require("./registerValidation");

const schema = {};

schema["register"] = registerSchema;

module.exports = schema;
