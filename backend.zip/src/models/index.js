const KategoriMovie = require("./KategoriMovie");
const Movie = require("./Movie");
const Pengguna = require("./Pengguna");
const Heroes = require("./Heroes")

module.exports = {
    KategoriMovie,
    Movie,
    Pengguna,
    Heroes
};
